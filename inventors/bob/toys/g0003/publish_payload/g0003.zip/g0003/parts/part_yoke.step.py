"""yoke — CLEARANCE (g0003). Contract: ../brief.md §2 yoke.

Print orientation: bed datum at Z = 0.
"""

import clearance_lib as lib


def gen_step():
    return lib.print_yoke()
